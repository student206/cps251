package com.aukish.recycleviewintents

import androidx.lifecycle.ViewModel
import kotlin.random.Random

class MainViewModel : ViewModel() {

    private val randomTitles = List(8) { Random.nextInt(0, 8) }
    private val randomDetails = List(8) { Random.nextInt(0, 8) }
    private val randomImages = List(8) { Random.nextInt(0, 8) }

    fun getTitle(i : Int) : Int {
        return randomTitles[i]
    }
    fun getDetail(i : Int) : Int {
        return randomDetails[i]
    }
    fun getImage(i : Int) : Int {
        return randomImages[i]
    }

}