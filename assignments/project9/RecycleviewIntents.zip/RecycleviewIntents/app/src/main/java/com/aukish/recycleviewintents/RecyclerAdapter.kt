package com.aukish.recycleviewintents

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecyclerAdapter(private val viewModel : MainViewModel) : RecyclerView.Adapter<RecyclerAdapter.ViewHolder>() {

    var data = Data()

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var itemImage: ImageView
        var itemTitle: TextView
        var itemDetail: TextView

        init {
            itemImage = itemView.findViewById(R.id.itemImage)
            itemTitle = itemView.findViewById(R.id.itemTitle)
            itemDetail = itemView.findViewById(R.id.itemDetail)


        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        val v = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.card_layout, viewGroup, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        viewHolder.itemTitle.text = data.titles[viewModel.getTitle(i)]
        viewHolder.itemDetail.text = data.details[viewModel.getDetail(i)]
        viewHolder.itemImage.setImageResource(data.images[viewModel.getImage(i)])

        viewHolder.itemView.setOnClickListener { v: View ->
            val intent = Intent(v.context, MainActivity2::class.java)
            intent.putExtra("title", data.titles[viewModel.getTitle(i)])
            intent.putExtra("detail", data.details[viewModel.getDetail(i)])
            intent.putExtra("image", data.images[viewModel.getImage(i)])
            v.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return data.titles.size
    }

}