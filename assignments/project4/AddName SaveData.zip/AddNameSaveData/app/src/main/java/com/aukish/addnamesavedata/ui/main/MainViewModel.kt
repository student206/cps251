package com.aukish.addnamesavedata.ui.main

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    // TODO: Implement the ViewModel

    private var nameText = ""
    private var names = ""

    fun addName(name: String) {
        this.nameText = name
        names += name + "\n"
    }

    fun getNames(): String {
        if (names.isEmpty()) {
            return "No names to display"
        }
        return names
    }
}