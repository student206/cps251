package com.aukish.addnamesavedata2.ui.main

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    // TODO: Implement the ViewModel

    public var name: MutableLiveData<String> = MutableLiveData()
    public var names: MutableLiveData<String> = MutableLiveData()

    fun addName() {
        name.let {
            if (!it.value.equals("")) {
                names.value = names.value.toString() + it.value.toString() + "\n"
            }
        }
    }


}