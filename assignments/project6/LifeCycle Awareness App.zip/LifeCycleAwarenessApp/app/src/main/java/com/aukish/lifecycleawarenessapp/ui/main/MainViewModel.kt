package com.aukish.lifecycleawarenessapp.ui.main

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import java.sql.Time
import java.time.LocalTime

class MainViewModel : ViewModel() {
    // TODO: Implement the ViewModel
    companion object {
        var text: MutableLiveData<String> = MutableLiveData()

        fun addText(newText: String, time: LocalTime) {
            if (text.value == null) {
                text.value = ""
            }

            text.value = text.value + newText + " was fired on " + time + "\n"

            if (newText == "onResume" || newText == "onPause" || newText == "onDestroy") {
                text.value += "********** \n"
            }
            return
        }
    }

}