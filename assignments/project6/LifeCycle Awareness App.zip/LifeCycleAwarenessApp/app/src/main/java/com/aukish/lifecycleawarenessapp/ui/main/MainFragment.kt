    package com.aukish.lifecycleawarenessapp.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.aukish.lifecycleawarenessapp.DemoObserver
import com.aukish.lifecycleawarenessapp.R
import androidx.databinding.DataBindingUtil
import com.aukish.lifecycleawarenessapp.databinding.FragmentMainBinding
import com.aukish.lifecycleawarenessapp.BR.myViewModel


    class MainFragment : Fragment() {

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var viewModel: MainViewModel
    lateinit var binding: FragmentMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)


        lifecycle.addObserver(DemoObserver())



        // TODO: Use the ViewModel
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DataBindingUtil.inflate(
            inflater, R.layout.fragment_main, container, false)
        binding.setLifecycleOwner(this)
        binding.setVariable(myViewModel, viewModel)
        return binding.root

    }

}