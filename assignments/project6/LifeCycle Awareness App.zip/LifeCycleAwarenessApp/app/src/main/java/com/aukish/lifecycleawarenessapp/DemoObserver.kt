package com.aukish.lifecycleawarenessapp

import android.util.Log
import androidx.lifecycle.*
import com.aukish.lifecycleawarenessapp.ui.main.MainViewModel.Companion.addText
import java.time.LocalTime


class DemoObserver: DefaultLifecycleObserver {

    private val LOG_TAG = "DemoObserver"

    override fun onResume(owner: LifecycleOwner) {
        Log.i(LOG_TAG, "onResume")
        addText("onResume", LocalTime.now())
    }
    override fun onPause(owner: LifecycleOwner) {
        Log.i(LOG_TAG, "onPause")
        addText("onPause", LocalTime.now())
    }
    override fun onCreate(owner: LifecycleOwner) {
        Log.i(LOG_TAG, "onCreate")
        addText("onCreate", LocalTime.now())
    }
    override fun onStart(owner: LifecycleOwner) {
        Log.i(LOG_TAG, "onStart")
        addText("onStart", LocalTime.now())
    }
    override fun onStop(owner: LifecycleOwner) {
        Log.i(LOG_TAG, "onStop")
        addText("onStop", LocalTime.now())
    }
    override fun onDestroy(owner: LifecycleOwner) {
        Log.i(LOG_TAG, "onDestroy")
        addText("onDestroy", LocalTime.now())
    }
    fun onAny(owner: LifecycleOwner, event: Lifecycle.Event) {
        Log.i(LOG_TAG, owner.lifecycle.currentState.name)
        addText(owner.lifecycle.currentState.name, LocalTime.now())
    }
}