package com.aukish.coroutine

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.aukish.coroutine.databinding.ActivityMainBinding
import kotlinx.coroutines.*
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val coroutineScope = CoroutineScope(Dispatchers.Main)

    private var layoutManager: RecyclerView.LayoutManager? = null
    private var adapter: RecyclerView.Adapter<RecyclerAdapter.ViewHolder>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        layoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = layoutManager
        adapter = RecyclerAdapter()
        binding.recyclerView.adapter = adapter

    }

    private fun performTaskAsync(name: String): Deferred<String> =
        coroutineScope.async(Dispatchers.Main) {
            val ranNum = Random.nextLong(1, 11) * 1000
            binding.newName.setText("")
            delay(ranNum)
            MainViewModel().addDetail("The name is $name and the delay was $ranNum milliseconds")
            adapter?.notifyDataSetChanged()
            return@async "Finished Coroutine"
    }

    fun launchCoroutines(view: View) {
            coroutineScope.launch(Dispatchers.Main) {
                performTaskAsync(binding.newName.text.toString()).await()
            }
    }
}