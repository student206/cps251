package com.aukish.coroutine

import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {

    fun getDetails(): MutableList<String> {
        return details
    }

    fun addDetail(newDetail : String) {
        details.add(newDetail)
    }

    companion object {
        val details = mutableListOf<String>()
    }

}