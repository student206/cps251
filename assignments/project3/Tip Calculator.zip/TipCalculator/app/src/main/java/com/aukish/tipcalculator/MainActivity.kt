package com.aukish.tipcalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.aukish.tipcalculator.databinding.ActivityMainBinding
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.roundToLong

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    fun calculateTip(view: View) {
        if (binding.billText.text.isNotEmpty()) {
            val billValue = binding.billText.text.toString().toDouble()
            val tip10 = (billValue * 11)/10
            val tip15 = (billValue * 115)/100
            val tip20 = (billValue * 12)/10
            val round10 = BigDecimal(tip10).setScale(2, RoundingMode.HALF_EVEN)
            val round15 = BigDecimal(tip15).setScale(2, RoundingMode.HALF_EVEN)
            val round20 = BigDecimal(tip20).setScale(2, RoundingMode.HALF_EVEN)
            val tip10Text = "10% = $round10"
            val tip15Text = "15% = $round15"
            val tip20Text = "20% = $round20"

            binding.errorView.text = ""
            binding.textView.text = "The tips are as follows:"
            binding.tip10View.text = tip10Text
            binding.tip15View.text = tip15Text
            binding.tip20View.text = tip20Text
        } else {
            binding.errorView.text = "YOU MUST ENTER A BILL AMOUNT"
            binding.textView.text = ""
            binding.tip10View.text = ""
            binding.tip15View.text = ""
            binding.tip20View.text = ""

        }
    }
}