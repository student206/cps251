package com.aukish.contactsproject

import android.provider.ContactsContract
import androidx.annotation.NonNull
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contacts")
class Contact {

    @PrimaryKey(autoGenerate = true)
    @NonNull
    @ColumnInfo(name = "contactID")
    var id: Int = 0

    @ColumnInfo(name = "contactName")
    var contactName: String? = null

    @ColumnInfo(name = "contactPhone")
    var contactPhone: String? = null

    constructor() {}

    constructor(id: Int, contactname: String, contactPhone: String) {
        this.contactName = contactname
        this.contactPhone = contactPhone
    }

    constructor(contactname: String, contactPhone: String) {
        this.contactName = contactname
        this.contactPhone = contactPhone
    }

}