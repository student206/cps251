package com.aukish.contactsproject.ui.main

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.aukish.contactsproject.Contact
import com.aukish.contactsproject.R


class ContactListAdapter(private val contactItemLayout: Int, private val delInterface: DelInterface) :
    RecyclerView.Adapter<ContactListAdapter.ViewHolder>() {

    private var contactList: List<Contact>? = null

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var name: TextView = itemView.findViewById(R.id.name)
        var phone: TextView = itemView.findViewById(R.id.phone)
        var delButton: ImageView = itemView.findViewById(R.id.delButton)
    }

    override fun onBindViewHolder(holder: ViewHolder, listPosition: Int) {
        val name = holder.name
        val phone = holder.phone
        val delButton = holder.delButton
        val id: Int
        contactList.let {
            name.text = it!![listPosition].contactName
            phone.text = it!![listPosition].contactPhone
            id = it!![listPosition].id
        }

        delButton.setOnClickListener {
            delInterface.getId(id)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):
            ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(
            contactItemLayout, parent, false)

        return ViewHolder(view)
    }

    fun setContactList(contacts: List<Contact>) {
        contactList = contacts
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return if (contactList == null) 0 else contactList!!.size
    }

    fun interface DelInterface {
        fun getId(id: Int)
    }

}