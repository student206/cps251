package com.aukish.contactsproject.ui.main

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.aukish.contactsproject.R
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.aukish.contactsproject.Contact
import androidx.fragment.app.viewModels
import com.aukish.contactsproject.databinding.FragmentMainBinding

class MainFragment() : Fragment(), ContactListAdapter.DelInterface {

    private var adapter: ContactListAdapter? = null

    companion object {
        fun newInstance() = MainFragment()
    }

    val viewModel: MainViewModel by viewModels()
    private var _binding: FragmentMainBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMainBinding.inflate(inflater, container, false)
        listenerSetup()
        observerSetup()
        recyclerSetup()
        return binding.root
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    private fun clearFields() {
        binding.Name.setText("")
        binding.Phone.setText("")
    }

    private fun listenerSetup() {
        binding.addButton.setOnClickListener {
            val name = binding.Name.text.toString()
            val phone = binding.Phone.text.toString()

            if (name != "" && phone != "") {
                val contact = Contact(name, phone)
                viewModel.insertContact(contact)
                clearFields()
            } else {
                Toast.makeText(activity, "Please enter a name and phone number", Toast.LENGTH_SHORT).show()
            }
        }
        binding.findButton.setOnClickListener {
            val name = binding.Name.text.toString()

            if (name != "") {
                viewModel.findContacts(
                    binding.Name.text.toString()
                )
            } else {
                Toast.makeText(activity, "You must enter a search criteria in the name field", Toast.LENGTH_SHORT).show()
            }
        }

        binding.ascButton.setOnClickListener { viewModel.ascContacts() }

        binding.descButton.setOnClickListener { viewModel.descContacts() }
    }

    private fun observerSetup() {
        viewModel.getAllContacts()?.observe(viewLifecycleOwner, Observer { contacts ->
            contacts?.let {
                adapter?.setContactList(it)
            }
        })

        viewModel.getSearchResults().observe(viewLifecycleOwner, Observer { contacts ->
            contacts?.let {

                if (it.isNotEmpty()) {
                    adapter?.setContactList(it)
                } else {
                    Toast.makeText(activity, "There are no contacts that match your search", Toast.LENGTH_SHORT).show()
                }
            }
        })

        viewModel.getAscResults()?.observe(viewLifecycleOwner, Observer { contacts ->
            contacts?.let {
                    adapter?.setContactList(it)
            }
        })
//
        viewModel.getDescResults()?.observe(viewLifecycleOwner, Observer { contacts ->
            contacts?.let {
                adapter?.setContactList(it)
            }
        })
    }

    private fun recyclerSetup() {
        adapter = ContactListAdapter(R.layout.card_layout, this)
        binding.contactRecycler.layoutManager = LinearLayoutManager(context)
        binding.contactRecycler.adapter = adapter
    }

    override fun getId(id: Int) {
        viewModel.deleteContact(id)
    }
}